import React from "react";
import "./App.css";
import Country from "./components/Country";
import Weather from "./components/Weather";
import { BrowserRouter, Route, Routes, Link } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Country />} />
        <Route path="/weather/:id" element={<Weather />} />
      </Routes>
    </div>
  );
}

export default App;
