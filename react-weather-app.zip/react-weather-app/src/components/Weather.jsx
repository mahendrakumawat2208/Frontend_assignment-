import React from "react";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useState } from "react";

function Weather() {
  const { id } = useParams();
  const [weather, setWeather] = useState({});
  const [wind, setWind] = useState({});

  const getWeather = async () => {
    const url =
      "https://api.openweathermap.org/data/2.5/weather?q=" +
      id +
      "&APPID=794ee95e63c5a32aaf88cd813fa2e425";
    const getData = await axios.get(url);
    console.log(getData.data.main);
    setWeather(getData.data.main);
    setWind(getData.data.wind);
    // setCountries(getData.data.data);
  };

  useEffect(() => {
    getWeather();
  }, []);

  return (
    <div>
      <h1 className="app-name">Weather</h1>
      <p className="country-div">Country Name: {id}</p>
      <p className="country-div">Temperature: {weather.temp} K</p>
      <p className="country-div">Humidity: {weather.humidity} %</p>
      <p className="country-div">Wind Data</p>
      <p className="country-div">Wind Speed: {wind.speed} m/s</p>
    </div>
  );
}

export default Weather;
