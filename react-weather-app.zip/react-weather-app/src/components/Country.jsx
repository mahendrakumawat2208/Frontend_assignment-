import React, { useEffect } from "react";
import axios from "axios";
import { useState } from "react";

function Country() {
  const [countries, setCountries] = useState([]);

  const getCountries = async () => {
    const getData = await axios.get(
      "https://countriesnow.space/api/v0.1/countries"
    );
    console.log(getData.data.data[0]);
    setCountries(getData.data.data);
  };

  useEffect(() => {
    getCountries();
  }, []);
  return (
    <div>
      <h1 className="app-name">Weather</h1>
      {countries.map((country) => (
        <div className="country-div">
          <a href={"/weather/" + country.country}>{country.country}</a>
        </div>
      ))}
    </div>
  );
}

export default Country;
